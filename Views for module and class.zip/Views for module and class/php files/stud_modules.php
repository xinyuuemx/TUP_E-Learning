
		<div class="main">
			<div class="inner">
				<header class="special">
					<h2>WEb Programming Lecture</h2>
						<ul class="alt">
							<li>School Year 2017-2018</li>
							<li>Second Semester</li>
						</ul>
				</header>
				<div class="highlights">
					<section>
						<div class="content">
							<header>
								<h3>Web Progamming Lecture</h3>
								<p>Lecture I</p>
							</header>
								<div id="first">JavaScript<br>
									<div id="gap"></div>
									<div id="fifth">Description<br><br><br></div>
									<div id="gap"></div>
									<a href="stud_discussion.html"><div id="fourth"> View Discussion </div></a>
									<div id="gap"></div>
										<a href="mama.com"><div id="second">Read Online</div></a>
									<a href="stud_modules.html"><div id="third">PDF Download</div></a>
								</div>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<h3>Web Progamming Lecture</h3>
								<p>Lecture II</p>
							</header>
								<div id="first">Bootstrap<br>
									<div id="gap"></div>
									<div id="fifth">Description<br><br><br></div>
									<div id="gap"></div>
										<a href="stud_discussion.html"><div id="fourth"> View Discussion </div></a>
									<div id="gap"></div>
										<a href="mama.com"><div id="second">Read Online</div></a>
										<a href="mama.com"><div id="third">PDF Download</div></a>
									</div>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<h3>Web Progamming Lecture</h3>
								<p>Lecture III</p>
							</header>
								<div id="first">Title<br>
									<div id="gap"></div>
									<div id="fifth">Description<br><br><br></div>
									<div id="gap"></div>
										<a href="stud_discussion.html"><div id="fourth"> View Discussion </div></a>
									<div id="gap"></div>
										<a href="mama.com"><div id="second">Read Online</div></a>
										<a href="mama.com"><div id="third">PDF Download</div></a>
									</div>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-stop"><span class="label">Icon</span>
								<h2>Recent Activity</h2></a>
							</header>
							<p> 
							<h3>None</h3> 
							</p>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<h3>Web Progamming Lecture
								<p><br />Quiz</p></h3>
							</header>
								<div id="first">JavaScript<br>
									<div id="gap"></div>
									<div id="fifth">Description<br><br><br></div>
									<div id="gap"></div>
									<h2><a href="stud_discussion.html"><div id="fourth"> Take Quiz </div></a></h2>
									
								</div>
						</div>
					</section>
					
					

</div>
</div>
</div> 

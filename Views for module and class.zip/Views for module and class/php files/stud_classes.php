
		<div class="main">
			<div class="inner">
				<header class="special">
					<h2>Classes</h2>
						<ul class="alt">
							<li>School Year 2017-2018</li>
							<li>Second Semester</li>
						</ul>
				</header>
				<div class="highlights">
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS321</h2></a>
							</header>
							<p>Web Progamming Lecture<br />
							Prof. Renato Bituonan
							
							</p>
							
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CSF2</h2></a>
							</header>
							<p>Free Elective 2 <br />
							Prof. Nitz Calayag
							
							</p>
						</div>
					</section><section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS321L</h2></a>
							</header>
							<p>Web Progamming Laboratory<br />
							Prof. Renato Bituonan
							
							</p>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS322</h2></a>
							</header>
							<p>Software Engineering <br />
							Prof. May Garcia 
							
							</p>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS323</h2></a>
							</header>
							<p>Operating Systems <br />
							Prof. Marics Francisco
							</p>
						</div>
					</section>
				</div>
				
			


</div>

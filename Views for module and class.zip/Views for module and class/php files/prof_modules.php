 
		<div class="main">
			<div class="inner">
				<header class="special">
					<h2>WEb Programming Lecture</h2>
						<ul class="alt">
							<li>School Year 2017-2018</li>
							<li>Second Semester</li>
						</ul>
				</header>



				<div class="highlights">
					
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-plus"><span class="label">Icon</span>
								<h2><br />Add Module</h2></a>
							</header>
							
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<h3>Web Progamming Lecture</h3>
								<p>Lecture I</p>
							</header>
								<div id="first">JavaScript<br>
									<div id="gap"></div>
									<div id="fifth">Description<br><br><br></div>
									<div id="gap"></div>
									<h2><a href="#"><div id="fourth"> Add Quiz </div></a></h2>
									
								</div>
						</div>
					</section>


					
					

</div>
</div>
</div> 



		<div class="main">
			<div class="inner">
				<header class="special">
					<h2>Classes</h2>
						<ul class="alt">
							<li>School Year 2017-2018</li>
							<li>Second Semester</li>
						</ul>
				</header>
				<div class="highlights">
					
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-stop"><span class="label">Icon</span>
								<h2>No Available Class</h2></a>
							</header>
							<p> <br />
							
							</p>
						</div>
					</section>
				</div>
				
			


</div>
	 
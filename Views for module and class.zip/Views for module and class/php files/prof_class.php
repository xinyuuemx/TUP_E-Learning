
		<div class="main">
			<div class="inner">
				<header class="special">
					<h2>Classes</h2>
						<ul class="alt">
							<li>School Year 2017-2018</li>
							<li>Second Semester</li>
						</ul>
				</header>
				<div class="highlights">
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-plus"><span class="label">Icon</span>
								<h2>Add Class</h2></a>
							</header>
							<p> <br />
							
							</p>
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS321</h2></a>
							</header>
							<p>Web Progamming Lecture<br />
							BSCS 3A
							
							</p>
							
						</div>
					</section>
					<section>
						<div class="content">
							<header>
								<a href="#" class="icon fa-graduation-cap"><span class="label">Icon</span>
								<h2>CS321</h2></a>
							</header>
							<p>Web Programing Lecture <br />
							BSCS 3B
							
							</p>
						</div>
					</section>
</div>
	 